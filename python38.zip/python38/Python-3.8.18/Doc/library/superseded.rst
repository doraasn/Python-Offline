.. _superseded:

******************
Superseded Modules
******************

The modules described in this chapter are deprecated and only kept for
backwards compatibility. They have been superseded by other modules.


.. toctree::

   optparse.rst
   imp.rst
